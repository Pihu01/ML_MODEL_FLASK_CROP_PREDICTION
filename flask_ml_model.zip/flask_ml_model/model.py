import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
#to load load the dataset file
data = pd.read_csv('Crop_recommendation.csv')
#to check first 5 rows of data
# data.head()

# #to check how many rows and columns are there
# data.shape

#to check if there are any null value in the dataset
data.isnull().sum()
#split in features and labels
x =  data.iloc[:,:-1] #features
y = data.iloc[:,-1] #labels

#separating data to train and test
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2,random_state =42)

#create and train your model
model = RandomForestClassifier()
model.fit(x_train,y_train)

# predictions = model.predict(x_test)
# accuracy = model.score(x_test, y_test)
# print(accuracy)

# #creating pickle file
# pickle.dump(model,open('model.pkl',"wb"))

# Save the model to a pickle file
with open('model.pkl', 'wb') as f: 
    pickle.dump(model, f)

#####this is the integration part which should be done on flask###
# # Load the model from the pickle file
# with open('model.pkl', 'rb') as f:
#     loaded_model = pickle.load(f)

# # Use the loaded model for predictions
# new_features = [[36,58,25,28.66024,59.31891,8.399136,36.9263]]
# predicted_corp = loaded_model.predict(new_features)
# print(predicted_corp)
