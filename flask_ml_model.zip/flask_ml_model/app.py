from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

app = Flask(__name__)

with open('model.pkl', 'rb') as f:
    loaded_model = pickle.load(f)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=["POST"])
def predict():
    print('1')
    float_feature = [float(x) for x in request.form.values()]
    print('2')
    features = [np.array(float_feature)]
    print('3')
    prediction = loaded_model.predict(features)
    print('4')
    prediction_text="The Predicted Crop is: {}".format(prediction[0])
    print(prediction_text)
    return render_template('index.html',prediction_text=prediction_text)

if __name__ == '__main__':
    app.run(debug=True)